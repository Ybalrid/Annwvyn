#include <Annwvyn.h>

int main()
{
    Annwvyn::AnnEngine GameEngine("test");

    GameEngine.loadZip("media/OgreOculus.zip");
    GameEngine.initRessources();

    GameEngine.oculusInit();
    
    while(!GameEngine.requestStop())
    {
        GameEngine.refresh();
    }
}
